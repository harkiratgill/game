﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace russian_rollete

{
 

    public partial class Form2 : Form
    {
        int l1;
        int S1;
        int C1;
        int W1;
        int S2;
        int L2;
        int l;
        int w;
        int k = 2;
        int s;

        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            

           
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Text = Convert.ToString(s);
            label3.Text = Convert.ToString(w);
            label4.Text = Convert.ToString(l);
            label2.Text = Form1.a;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {// thsi code is for the picturebox
                pictureBox1.Visible = true;
                Image img = Image.FromFile(@"C:\Users\sunny\source\repos\russian rollete\res\load.gif");
                pictureBox1.Image = img;
                //this code is for the sound
                System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\sunny\source\repos\russian rollete\res\sound.wav");
                player.Play();
                // this code is for loding of the one bullete
                l1 = 1;


                button2.Enabled = true;
                button1.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
            Image img = Image.FromFile(@"C:\Users\sunny\source\repos\russian rollete\res\spinnn.gif");
            pictureBox1.Image = img;

            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\sunny\source\repos\russian rollete\res\spinnn.wav");
            player.Play();

            //this code is for random it helps to pick up a random number betwwen 1-7

            Random rnd = new Random();

            S1 = rnd.Next(1, 7);
            button3.Enabled = true;
            button2.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //this code is for the piture box
            pictureBox1.Visible = true;
            
            Image img = Image.FromFile(@"C:\Users\sunny\source\repos\russian rollete\res\shots.gif");
            pictureBox1.Image = img;
            // this code is for the sound
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\sunny\source\repos\russian rollete\res\gun.wav");
            player.Play();

            if (C1 < 2)
            {

                if (S1 == l1)
                {
                    W1 = W1 + 1;
                    S2 = S2 + 10;
                    S1 = S1 + 1;
                    C1 = 3;
                    MessageBox.Show("you won and your score is " + S2);
                    label1.Text = Convert.ToString(s); // this code is to update score in every round
                    label3.Text = Convert.ToString(w);
                    label4.Text = Convert.ToString(l);
                    w = w + 1; // this code is to keep track of the score 
                    s = s + 10;
                    k = k - 1;
                    label1.Text = Convert.ToString(s);// this code is to update score in every round
                    label3.Text = Convert.ToString(w);
                    label4.Text = Convert.ToString(l);
                    MessageBox.Show("Next Game");
                    button1.Enabled = true; // this code is here to enable button after the round
                    button2.Enabled = true;
                    button3.Enabled = true;
                    l1 = 0;// this code reset all the varaibles for the next round
                    S1 = 0;
                    C1 = 0;
                    W1 = 0;
                    S2 = 0;
                    L2 = 0;
                    k = 2;
                }
                else
                {
                    score s = new score();
                    S1 = s.sco(S1);
                    C1 = C1 + 1;
                }

            }
            else
            {
                L2 = L2 + 1;
               
            }
            if (C1 >= 2)
            { // this code is for the pop up of win or loss
                if (S2 != 0)
                {
                    MessageBox.Show("you won and your score is " + S2);
                    
                    w = w + 1;
                    s = s + 10;
                    k = k - 1;
                    label1.Text = Convert.ToString(s);// this code will update  score board
                    label3.Text = Convert.ToString(w);
                    label4.Text = Convert.ToString(l);
                    MessageBox.Show("Next Game");
                    button1.Enabled = true; // this code will enable the buttons for next round
                    button2.Enabled = true;
                    button3.Enabled = true;
                    l1 = 0;// this code is to rest all the variables fo the next round
                    S1 = 0;
                    C1 = 0;
                    W1 = 0;
                    S2 = 0;
                    L2 = 0;
                    k = 2;


                }
                else
                {
                    MessageBox.Show("you loss and your score is " + S2);
                    l = l + 1;

                    label1.Text = Convert.ToString(s);// this code is to update score box
                    label3.Text = Convert.ToString(w);
                    label4.Text = Convert.ToString(l);
                    k = k - 1;


                }
            }
            if (k == 0)
            {
                MessageBox.Show("Next Game");// tis code is to rest the bounnton and variables if you losses the both round
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                l1 = 0;
                S1 = 0;
                C1 = 0;
                W1 = 0;
                S2 = 0;
                L2 = 0;
                k = 2;
            }

        }


        private void button4_Click(object sender, EventArgs e)
        {
            (new Form2()).Show();
            this.Close();
        }
    }
}