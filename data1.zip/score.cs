﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace russian_rollete
{
    class score
    {
        public int sco(int Spin1)
        {
            if (Spin1 == 6)
            {
                Spin1 = 1;
            }
            else
            {
                Spin1 = Spin1 + 1;
            }

            return Spin1;
        }
    }
}
