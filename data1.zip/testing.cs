﻿using NUnit.Framework;

namespace russian_rollete
{
    [TestFixture]
    public class testing
    {
        [TestCase]
        public void score_test()
        {
            score test = new score();
            Assert.AreEqual(1,test.sco(6));
        }

        
            [TestCase]
            public void score_test_neg()
            {
                score test_neg = new score();
                Assert.AreNotEqual(2, test_neg.sco(6));

            }
        }
}